/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import domain.Administrator;
import domain.Igrac;
import domain.Korisnik;
import domain.Opstina;
import domain.Teren;
import domain.Termin;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import session.Session;
import transfer.Request;
import transfer.Response;
import transfer.util.ResponseStatus;
import transfer.util.Operation;

/**
 *
 * @author Antonije
 */
public class ClientController {

    private static ClientController instance;

    public ClientController() {
    }

    public static ClientController getInstance() {
        if (instance == null) {
            instance = new ClientController();
        }
        return instance;
    }

    public Administrator login(Administrator administrator) throws Exception {
        return (Administrator) sendRequest(Operation.LOGIN, administrator);
    }

    public void addKorisnik(Korisnik korisnik) throws Exception {
        sendRequest(Operation.ADD_KORISNIK, korisnik);
    }

    public void addTermin(Termin termin) throws Exception {
        sendRequest(Operation.ADD_TERMIN, termin);
    }
    
    public void addTeren(Teren teren) throws Exception {
        sendRequest(Operation.ADD_TEREN, teren);
    }

    public void deleteKorisnik(Korisnik korisnik) throws Exception {
        sendRequest(Operation.DELETE_KORISNIK, korisnik);
    }

    public void deleteTermin(Termin termin) throws Exception {
        sendRequest(Operation.DELETE_TERMIN, termin);
    }

    public void updateKorisnik(Korisnik korisnik) throws Exception {
        sendRequest(Operation.UPDATE_KORISNIK, korisnik);
    }

    public void updateTermin(Termin termin) throws Exception {
        sendRequest(Operation.UPDATE_TERMIN, termin);
    }
    
    public void updateTeren(Teren teren) throws Exception {
        sendRequest(Operation.UPDATE_TEREN, teren);
    }

    public ArrayList<Administrator> getAllAdministrator() throws Exception {
        return (ArrayList<Administrator>) sendRequest(Operation.GET_ALL_ADMINISTRATOR, null);
    }

    public ArrayList<Korisnik> getAllKorisnik() throws Exception {
        return (ArrayList<Korisnik>) sendRequest(Operation.GET_ALL_KORISNIK, null);
    }

    public ArrayList<Termin> getAllTermin() throws Exception {
        return (ArrayList<Termin>) sendRequest(Operation.GET_ALL_TERMIN, null);
    }

    public ArrayList<Opstina> getAllOpstina() throws Exception {
        return (ArrayList<Opstina>) sendRequest(Operation.GET_ALL_OPSTINA, null);
    }

    public ArrayList<Teren> getAllTeren() throws Exception {
        return (ArrayList<Teren>) sendRequest(Operation.GET_ALL_TEREN, null);
    }

    public ArrayList<Igrac> getAllIgrac(Termin t) throws Exception {
        return (ArrayList<Igrac>) sendRequest(Operation.GET_ALL_IGRAC, t);
    }

    private Object sendRequest(int operation, Object data) throws Exception {
        Request request = new Request(operation, data);

        ObjectOutputStream out = new ObjectOutputStream(Session.getInstance().getSocket().getOutputStream());
        out.writeObject(request);

        ObjectInputStream in = new ObjectInputStream(Session.getInstance().getSocket().getInputStream());
        Response response = (Response) in.readObject();

        if (response.getResponseStatus().equals(ResponseStatus.Error)) {
            throw response.getException();
        } else {
            return response.getData();
        }

    }
}
