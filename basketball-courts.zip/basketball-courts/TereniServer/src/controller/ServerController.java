/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import domain.Administrator;
import domain.Igrac;
import domain.Korisnik;
import domain.Opstina;
import domain.Teren;
import domain.Termin;
import java.util.ArrayList;
import so.administrator.SOGetAllAdministrator;
import so.igrac.SOGetAllIgrac;
import so.korisnik.SOAddKorisnik;
import so.korisnik.SODeleteKorisnik;
import so.korisnik.SOGetAllKorisnik;
import so.korisnik.SOUpdateKorisnik;
import so.login.SOLogin;
import so.opstina.SOGetAllOpstina;
import so.teren.SOAddTeren;
import so.teren.SOGetAllTeren;
import so.teren.SOUpdateTeren;
import so.termin.SOAddTermin;
import so.termin.SODeleteTermin;
import so.termin.SOGetAllTermin;
import so.termin.SOUpdateTermin;

/**
 *
 * @author Antonije
 */
public class ServerController {

    private static ServerController instance;

    public ServerController() {
    }

    public static ServerController getInstance() {
        if (instance == null) {
            instance = new ServerController();
        }
        return instance;
    }

    public Administrator login(Administrator administrator) throws Exception {
        SOLogin so = new SOLogin();
        so.templateExecute(administrator);
        return so.getAdmin();
    }

    public void addKorisnik(Korisnik korisnik) throws Exception {
        (new SOAddKorisnik()).templateExecute(korisnik);
    }
    
    public void addTermin(Termin termin) throws Exception {
        (new SOAddTermin()).templateExecute(termin);
    }
    
    public void addTeren(Teren teren) throws Exception {
        (new SOAddTeren()).templateExecute(teren);
    }

    public void deleteKorisnik(Korisnik korisnik) throws Exception {
        (new SODeleteKorisnik()).templateExecute(korisnik);
    }

    public void deleteTermin(Termin termin) throws Exception {
        (new SODeleteTermin()).templateExecute(termin);
    }

    public void updateKorisnik(Korisnik korisnik) throws Exception {
        (new SOUpdateKorisnik()).templateExecute(korisnik);
    }

    public void updateTermin(Termin termin) throws Exception {
        (new SOUpdateTermin()).templateExecute(termin);
    }
    
    public void updateTeren(Teren teren) throws Exception {
        (new SOUpdateTeren()).templateExecute(teren);
    }

    public ArrayList<Administrator> getAllAdministrator() throws Exception {
        SOGetAllAdministrator so = new SOGetAllAdministrator();
        so.templateExecute(new Administrator());
        return so.getLista();
    }

    public ArrayList<Korisnik> getAllKorisnik() throws Exception {
        SOGetAllKorisnik so = new SOGetAllKorisnik();
        so.templateExecute(new Korisnik());
        return so.getLista();
    }

    public ArrayList<Termin> getAllTermin() throws Exception {
        SOGetAllTermin so = new SOGetAllTermin();
        so.templateExecute(new Termin());
        return so.getLista();
    }

    public ArrayList<Opstina> getAllOpstina() throws Exception {
        SOGetAllOpstina so = new SOGetAllOpstina();
        so.templateExecute(new Opstina());
        return so.getLista();
    }

    public ArrayList<Teren> getAllTeren() throws Exception {
        SOGetAllTeren so = new SOGetAllTeren();
        so.templateExecute(new Teren());
        return so.getLista();
    }

    public ArrayList<Igrac> getAllIgrac(Termin t) throws Exception {
        SOGetAllIgrac so = new SOGetAllIgrac();
        
        Igrac i = new Igrac();
        i.setTermin(t);
        
        so.templateExecute(i);
        return so.getLista();
    }

}
