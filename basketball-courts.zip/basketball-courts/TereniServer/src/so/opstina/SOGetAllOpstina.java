/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.opstina;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Opstina;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author Antonije
 */
public class SOGetAllOpstina extends AbstractSO {

    private ArrayList<Opstina> lista;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Opstina)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Opstina!");
        }
    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        ArrayList<AbstractDomainObject> opstine = DBBroker.getInstance().select(ado);
        lista = (ArrayList<Opstina>) (ArrayList<?>) opstine;
    }

    public ArrayList<Opstina> getLista() {
        return lista;
    }

}
