/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.teren;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Teren;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author Antonije
 */
public class SOAddTeren extends AbstractSO{

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if(!(ado instanceof Teren)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Teren!");
        }
        
        Teren t = (Teren) ado;
        
        ArrayList<Teren> tereni = (ArrayList<Teren>) (ArrayList<?>) DBBroker.getInstance().select(ado);
        
        for (Teren ter : tereni) {
            if (ter.getNazivTerena().equals(t.getNazivTerena())) {
                throw new Exception("Vec postoji teren sa tim nazivom!");
            }
        }
        
    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        DBBroker.getInstance().insert(ado);
    }
    
}
