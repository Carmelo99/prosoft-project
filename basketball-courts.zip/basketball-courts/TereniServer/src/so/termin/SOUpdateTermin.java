/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.termin;

import db.DBBroker;
import domain.AbstractDomainObject;
import domain.Igrac;
import domain.Termin;
import so.AbstractSO;

/**
 *
 * @author Antonije
 */
public class SOUpdateTermin extends AbstractSO {

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Termin)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Termin!");
        }

        Termin t = (Termin) ado;

        if (t.getIgraci().size() < 4 || t.getIgraci().size() > 15) {
            throw new Exception("Termin mora imati izmedju 4 i 15 igraca!");
        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {

        DBBroker.getInstance().update(ado);

        Termin t = (Termin) ado;
        DBBroker.getInstance().delete(t.getIgraci().get(0));

        for (Igrac igrac : t.getIgraci()) {
            DBBroker.getInstance().insert(igrac);
        }

    }

}
