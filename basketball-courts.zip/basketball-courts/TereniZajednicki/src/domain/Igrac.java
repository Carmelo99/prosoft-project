/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Antonije
 */
public class Igrac extends AbstractDomainObject {

    private Termin termin;
    private int rbIgraca;
    private String napomena;
    private Korisnik korisnik;

    public Igrac(Termin termin, int rbIgraca, String napomena, Korisnik korisnik) {
        this.termin = termin;
        this.rbIgraca = rbIgraca;
        this.napomena = napomena;
        this.korisnik = korisnik;
    }

    public Igrac() {
    }

    @Override
    public String nazivTabele() {
        return " igrac ";
    }

    @Override
    public String alijas() {
        return " i ";
    }

    @Override
    public String join() {
        return " JOIN TERMIN T USING (TERMINID) "
                + "JOIN KORISNIK KI ON (KI.KORISNIKID = I.KORISNIKID) "
                + "JOIN KORISNIK K ON (K.KORISNIKID = T.KORISNIKID) "
                + "JOIN TEREN TER ON (TER.TERENID = T.TERENID) "
                + "JOIN OPSTINA O ON (TER.TERENID = O.OPSTINAID) "
                + "JOIN ADMINISTRATOR A ON (A.ADMINISTRATORID = T.ADMINISTRATORID) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Administrator a = new Administrator(rs.getLong("AdministratorID"),
                    rs.getString("Ime"), rs.getString("Prezime"),
                    rs.getString("Username"), rs.getString("Password"));

            Opstina o = new Opstina(rs.getLong("OpstinaID"),
                    rs.getString("NazivOpstine"));

            Teren ter = new Teren(rs.getLong("terenID"), rs.getString("nazivTerena"),
                    rs.getString("adresa"), rs.getString("opis"), rs.getDouble("cenaPoSatu"), o);

            Korisnik k = new Korisnik(rs.getLong("KorisnikID"),
                    rs.getString("ImeKorisnika"), rs.getString("PrezimeKorisnika"),
                    rs.getString("Email"), rs.getString("telefon"));

            Termin t = new Termin(rs.getLong("terminID"), rs.getTimestamp("datumVremePocetka"),
                    rs.getTimestamp("datumVremeKraja"), rs.getInt("brojSati"), rs.getDouble("ukupnaCena"),
                    ter, k, a, null);

            Korisnik ki = new Korisnik(rs.getLong("ki.KorisnikID"),
                    rs.getString("ki.ImeKorisnika"), rs.getString("ki.PrezimeKorisnika"),
                    rs.getString("ki.Email"), rs.getString("ki.telefon"));

            Igrac i = new Igrac(t, rs.getInt("rbIgraca"), rs.getString("napomena"), ki);

            lista.add(i);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return " (terminID, rbIgraca, napomena, KorisnikID) ";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " terminID = " + termin.getTerminID();
    }

    @Override
    public String vrednostiZaInsert() {
        return termin.getTerminID() + ", " + rbIgraca + ", "
                + "'" + napomena + "', " + korisnik.getKorisnikID() + " ";
    }

    @Override
    public String vrednostiZaUpdate() {
        return "";
    }

    @Override
    public String uslov() {
        return " WHERE T.TERMINID = " + termin.getTerminID();
    }

    public Termin getTermin() {
        return termin;
    }

    public void setTermin(Termin termin) {
        this.termin = termin;
    }

    public int getRbIgraca() {
        return rbIgraca;
    }

    public void setRbIgraca(int rbIgraca) {
        this.rbIgraca = rbIgraca;
    }

    public String getNapomena() {
        return napomena;
    }

    public void setNapomena(String napomena) {
        this.napomena = napomena;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

}
