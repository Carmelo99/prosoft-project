/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Antonije
 */
public class Opstina extends AbstractDomainObject {

    private Long opstinaID;
    private String nazivOpstine;

    @Override
    public String toString() {
        return nazivOpstine;
    }

    public Opstina(Long opstinaID, String nazivOpstine) {
        this.opstinaID = opstinaID;
        this.nazivOpstine = nazivOpstine;
    }

    public Opstina() {
    }

    @Override
    public String nazivTabele() {
        return " opstina ";
    }

    @Override
    public String alijas() {
        return " o ";
    }

    @Override
    public String join() {
        return "";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Opstina o = new Opstina(rs.getLong("OpstinaID"),
                    rs.getString("NazivOpstine"));

            lista.add(o);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return "";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " OpstinaID = " + opstinaID;
    }

    @Override
    public String vrednostiZaInsert() {
        return "";
    }

    @Override
    public String vrednostiZaUpdate() {
        return "";
    }

    @Override
    public String uslov() {
        return "";
    }

    public Long getOpstinaID() {
        return opstinaID;
    }

    public void setOpstinaID(Long opstinaID) {
        this.opstinaID = opstinaID;
    }

    public String getNazivOpstine() {
        return nazivOpstine;
    }

    public void setNazivOpstine(String nazivOpstine) {
        this.nazivOpstine = nazivOpstine;
    }

}
