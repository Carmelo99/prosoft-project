/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Antonije
 */
public class Teren extends AbstractDomainObject {

    private Long terenID;
    private String nazivTerena;
    private String adresa;
    private String opis;
    private double cenaPoSatu;
    private Opstina opstina;

    @Override
    public String toString() {
        return nazivTerena + " (Opstina: " + opstina + ", Adresa: " + adresa + ", "
                + "Cena po satu: " + cenaPoSatu + "din)";
    }

    public Teren(Long terenID, String nazivTerena, String adresa, String opis, double cenaPoSatu, Opstina opstina) {
        this.terenID = terenID;
        this.nazivTerena = nazivTerena;
        this.adresa = adresa;
        this.opis = opis;
        this.cenaPoSatu = cenaPoSatu;
        this.opstina = opstina;
    }

    public Teren() {
    }

    @Override
    public String nazivTabele() {
        return " teren ";
    }

    @Override
    public String alijas() {
        return " ter ";
    }

    @Override
    public String join() {
        return " JOIN OPSTINA O ON (TER.OPSTINAID = O.OPSTINAID) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {

            Opstina o = new Opstina(rs.getLong("OpstinaID"),
                    rs.getString("NazivOpstine"));

            Teren ter = new Teren(rs.getLong("terenID"), rs.getString("nazivTerena"),
                    rs.getString("adresa"), rs.getString("opis"), rs.getDouble("cenaPoSatu"), o);

            lista.add(ter);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return "(NazivTerena,Adresa,Opis,CenaPoSatu,OpstinaID)";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " terenID = " + terenID;
    }

    @Override
    public String vrednostiZaInsert() {
        return "'"+nazivTerena+"','"+adresa+"','"+opis+"',"+cenaPoSatu+","+opstina.getOpstinaID();
    }

    @Override
    public String vrednostiZaUpdate() {
        return "NazivTerena='"+nazivTerena+"', Adresa='"+adresa+"', Opis='"+opis+"', CenaPoSatu="+cenaPoSatu+"";
    }

    @Override
    public String uslov() {
        return "";
    }

    public Long getTerenID() {
        return terenID;
    }

    public void setTerenID(Long terenID) {
        this.terenID = terenID;
    }

    public String getNazivTerena() {
        return nazivTerena;
    }

    public void setNazivTerena(String nazivTerena) {
        this.nazivTerena = nazivTerena;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public double getCenaPoSatu() {
        return cenaPoSatu;
    }

    public void setCenaPoSatu(double cenaPoSatu) {
        this.cenaPoSatu = cenaPoSatu;
    }

    public Opstina getOpstina() {
        return opstina;
    }

    public void setOpstina(Opstina opstina) {
        this.opstina = opstina;
    }

}
