/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Antonije
 */
public class Termin extends AbstractDomainObject {

    private Long terminID;
    private Date datumVremePocetka;
    private Date datumVremeKraja;
    private int brojSati;
    private double ukupnaCena;
    private Teren teren;
    private Korisnik korisnik;
    private Administrator administrator;
    private ArrayList<Igrac> igraci;

    public Termin(Long terminID, Date datumVremePocetka, Date datumVremeKraja, int brojSati, double ukupnaCena, Teren teren, Korisnik korisnik, Administrator administrator, ArrayList<Igrac> igraci) {
        this.terminID = terminID;
        this.datumVremePocetka = datumVremePocetka;
        this.datumVremeKraja = datumVremeKraja;
        this.brojSati = brojSati;
        this.ukupnaCena = ukupnaCena;
        this.teren = teren;
        this.korisnik = korisnik;
        this.administrator = administrator;
        this.igraci = igraci;
    }

    public Termin() {
    }

    @Override
    public String nazivTabele() {
        return " termin ";
    }

    @Override
    public String alijas() {
        return " t ";
    }

    @Override
    public String join() {
        return " JOIN KORISNIK K ON (K.KORISNIKID = T.KORISNIKID) "
                + "JOIN TEREN TER ON (TER.TERENID = T.TERENID) "
                + "JOIN OPSTINA O ON (TER.TERENID = O.OPSTINAID) "
                + "JOIN ADMINISTRATOR A ON (A.ADMINISTRATORID = T.ADMINISTRATORID) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Administrator a = new Administrator(rs.getLong("AdministratorID"),
                    rs.getString("Ime"), rs.getString("Prezime"),
                    rs.getString("Username"), rs.getString("Password"));

            Opstina o = new Opstina(rs.getLong("OpstinaID"),
                    rs.getString("NazivOpstine"));

            Teren ter = new Teren(rs.getLong("terenID"), rs.getString("nazivTerena"),
                    rs.getString("adresa"), rs.getString("opis"), rs.getDouble("cenaPoSatu"), o);

            Korisnik k = new Korisnik(rs.getLong("KorisnikID"),
                    rs.getString("ImeKorisnika"), rs.getString("PrezimeKorisnika"),
                    rs.getString("Email"), rs.getString("telefon"));

            Termin t = new Termin(rs.getLong("terminID"), rs.getTimestamp("datumVremePocetka"),
                    rs.getTimestamp("datumVremeKraja"), rs.getInt("brojSati"), rs.getDouble("ukupnaCena"),
                    ter, k, a, null);

            lista.add(t);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneZaInsert() {
        return " (datumVremePocetka, datumVremeKraja, brojSati, ukupnaCena, terenID, korisnikID, administratorID) ";
    }

    @Override
    public String vrednostZaPrimarniKljuc() {
        return " terminID = " + terminID;
    }

    @Override
    public String vrednostiZaInsert() {
        return "'" + new Timestamp(datumVremePocetka.getTime()) + "', "
                + "'" + new Timestamp(datumVremeKraja.getTime()) + "', "
                + brojSati + ", " + ukupnaCena + ", " + teren.getTerenID()
                + ", " + korisnik.getKorisnikID() + ", " + administrator.getAdministratorID();
    }

    @Override
    public String vrednostiZaUpdate() {
        return " datumVremePocetka = '" + new Timestamp(datumVremePocetka.getTime()) + "', "
                + "datumVremeKraja = '" + new Timestamp(datumVremeKraja.getTime()) + "', "
                + "brojSati = " + brojSati + ", ukupnaCena = " + ukupnaCena + " ";
    }

    @Override
    public String uslov() {
        return "";
    }

    public Long getTerminID() {
        return terminID;
    }

    public void setTerminID(Long terminID) {
        this.terminID = terminID;
    }

    public Date getDatumVremePocetka() {
        return datumVremePocetka;
    }

    public void setDatumVremePocetka(Date datumVremePocetka) {
        this.datumVremePocetka = datumVremePocetka;
    }

    public Date getDatumVremeKraja() {
        return datumVremeKraja;
    }

    public void setDatumVremeKraja(Date datumVremeKraja) {
        this.datumVremeKraja = datumVremeKraja;
    }

    public int getBrojSati() {
        return brojSati;
    }

    public void setBrojSati(int brojSati) {
        this.brojSati = brojSati;
    }

    public double getUkupnaCena() {
        return ukupnaCena;
    }

    public void setUkupnaCena(double ukupnaCena) {
        this.ukupnaCena = ukupnaCena;
    }

    public Teren getTeren() {
        return teren;
    }

    public void setTeren(Teren teren) {
        this.teren = teren;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public Administrator getAdministrator() {
        return administrator;
    }

    public void setAdministrator(Administrator administrator) {
        this.administrator = administrator;
    }

    public ArrayList<Igrac> getIgraci() {
        return igraci;
    }

    public void setIgraci(ArrayList<Igrac> igraci) {
        this.igraci = igraci;
    }

}
