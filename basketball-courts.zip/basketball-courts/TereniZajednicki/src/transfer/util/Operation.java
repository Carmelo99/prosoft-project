/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer.util;

/**
 *
 * @author Antonije
 */
public interface Operation {

    public static final int LOGIN = 0;

    public static final int GET_ALL_ADMINISTRATOR = 1;

    public static final int ADD_KORISNIK = 2;
    public static final int DELETE_KORISNIK = 3;
    public static final int UPDATE_KORISNIK = 4;
    public static final int GET_ALL_KORISNIK = 5;

    public static final int ADD_TERMIN = 6;
    public static final int DELETE_TERMIN = 7;
    public static final int UPDATE_TERMIN = 8;
    public static final int GET_ALL_TERMIN = 9;

    public static final int GET_ALL_IGRAC = 10;

    public static final int GET_ALL_OPSTINA = 11;
    
    public static final int ADD_TEREN = 12;
    public static final int DELETE_TEREN = 13;
    public static final int UPDATE_TEREN = 14;
    public static final int GET_ALL_TEREN = 15;

}
